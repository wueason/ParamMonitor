# ParamMonitor
Search in the page and give notices when params are missing
